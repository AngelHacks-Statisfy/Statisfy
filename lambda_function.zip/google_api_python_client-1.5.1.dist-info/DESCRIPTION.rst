The Google API Client for Python is a client library for
accessing the Plus, Moderator, and many other Google APIs.

